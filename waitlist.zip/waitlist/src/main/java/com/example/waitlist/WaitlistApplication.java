package com.example.waitlist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaitlistApplication {

	public static void main(String[] args) {
		SpringApplication.run(WaitlistApplication.class, args);
	}

}
